from random import randint
print("""Kő, papír, olló, gyík, Spock
Az Agymenők sorozatban elhangzó játékszabály alapján konzolos játékprogramot kell fejleszteni! Két gépi játékos játszik egymás ellen N(>0)-szer és statisztika készül arról, hogy melyikük hányszor nyert! A játékmenetet táblázatos elrendezésben meg kell jeleníteni és láttatni kell, hogy a nyertes a vesztessel szemben mivel nyert! Specifikálni kell, hogy lehet-e döntetlen! Akár igen akár nem, kezelni kell a helyzetet! A játékszabály képként is elérhető.
Szabály: olló > papír, papír > kő, kő > gyík, gyík > spock, spock > olló, olló > gyík, gyík > papír, papír > spock, spock > kő, kő > olló
""")

jatekszam=int(input("Hányszor játszanak? "))

t = ["Kő", "Papír", "Olló","Spock","Gyík"]

dontetlen=0
jatekos1=0
jatekos2=0

for i in range(0, jatekszam):

  comp1 = t[randint(0,4)]
  comp2 = t[randint(0,4)]
  
  if comp2 == comp1:
    print("Az első gépi játékos",comp1,", a második gépi játékos is",comp2,"döntetlen!")
    dontetlen+=1
  elif comp2 == "Kő" and comp1 == "Papír":
    print("Az első gépi játékos nyert mert", comp1, " üti ", comp2)
    jatekos1+=1
  elif comp2 == "Kő" and comp1 == "Olló":
    print("A második gépi játékos nyert mert", comp2, " üti ", comp1)
    jatekos2+=1
  elif comp2 == "Kő" and comp1 == "Gyík":
    print("A második gépi játékos nyert mert", comp2, " üti ", comp1)
    jatekos2+=1
  elif comp2 == "Kő" and comp1 == "Spock":
    print("A első gépi játékos nyert mert", comp1, " üti ", comp2)
    jatekos1+=1
  elif comp2 == "Papír" and comp1 == "Olló":
    print("A első gépi játékos nyert mert", comp1, " üti ", comp2)
    jatekos1+=1
  elif comp2 == "Papír" and comp1 == "Gyík":
    print("A első gépi játékos nyert mert", comp1, " üti ", comp2)
    jatekos1+=1
  elif comp2 == "Papír" and comp1 == "Spock":
    print("A második gépi játékos nyert mert", comp2, " üti ", comp1)
    jatekos2+=1
  elif comp2 == "Olló" and comp1 == "Gyík":
    print("A második gépi játékos nyert mert", comp2, "üti ", comp1)
    jatekos2+=1
  elif comp2 == "Olló" and comp1 == "Spock":
    print("A első gépi játékos nyert mert", comp1, " üti ", comp2)
    jatekos1+=1
  elif comp2 == "Gyík" and comp1 == "Spock":
    print("A második gépi játékos nyert mert", comp2, " üti ", comp1)
    jatekos2+=1


  elif comp1 == "Kő" and comp2 == "Papír":
    print("Az első gépi játékos vesztett mert", comp2, " üti ", comp1)
    jatekos1+=1
  elif comp1 == "Kő" and comp2 == "Olló":
    print("A második gépi játékos vesztett mert", comp1, " üti ", comp2)
    jatekos2+=1
  elif comp1 == "Kő" and comp2 == "Gyík":
    print("A második gépi játékos vesztett mert", comp1, " üti ", comp2)
    jatekos2+=1
  elif comp1 == "Kő" and comp2 == "Spock":
    print("A első gépi játékos vesztett mert", comp2, " üti ", comp1)
    jatekos1+=1
  elif comp1 == "Papír" and comp2 == "Olló":
    print("A első gépi játékos vesztett mert", comp2, " üti ", comp1)
    jatekos1+=1
  elif comp1 == "Papír" and comp2 == "Gyík":
    print("A első gépi játékos vesztett mert", comp2, " üti ", comp1)
    jatekos1+=1
  elif comp1 == "Papír" and comp2 == "Spock":
    print("A második gépi játékos vesztett mert", comp1, " üti ", comp2)
    jatekos2+=1
  elif comp1 == "Olló" and comp2 == "Gyík":
    print("A második gépi játékos vesztett mert", comp1, "üti ", comp2)
    jatekos2+=1
  elif comp1 == "Olló" and comp2 == "Spock":
    print("A első gépi játékos vesztett mert", comp2, " üti ", comp1)
    jatekos1+=1
  elif comp1 == "Gyík" and comp2 == "Spock":
    print("A második gépi játékos vesztett mert", comp1, " üti ", comp2)
    jatekos2+=1
print("")
print("Az első gépi játékos összesen",jatekos1,"alkalommal nyert a(z)", jatekszam,"játszmából")
print("A második gépi játékos összesen",jatekos2,"alkalommal nyert a(z)", jatekszam,"játszmából")
print("A(z)", jatekszam,"játszmából, összesen", dontetlen,"döntetlen játszma volt")




  